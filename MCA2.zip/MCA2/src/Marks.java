public class Marks {
    private Student student;
    private Course course;
    private int marksObtained;

    public Marks(Student student, Course course, int marksObtained) {
        this.student = student;
        this.course = course;
        this.marksObtained = marksObtained;
    }

    public Student getStudent() {
        return student;
    }

    public Course getCourse() {
        return course;
    }

    public int getMarksObtained() {
        return marksObtained;
    }
}