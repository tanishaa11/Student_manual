import java.util.List;

public class Certificate {
    private Student student;
    private List<Marks> marksList;

    public Certificate(Student student, List<Marks> marksList) {
        this.student = student;
        this.marksList = marksList;
    }

    public void printCertificate() {
        System.out.println("\n--- Certificate of Achievement ---");
        System.out.println("Student Name: " + student.getName());
        System.out.println("Student ID: " + student.getStudentId());
        System.out.println("Courses and Marks:");
        int total = 0;
        for (Marks m : marksList) {
            System.out.println("  " + m.getCourse().getCourseName() + ": " + m.getMarksObtained());
            total += m.getMarksObtained();
        }
        double avg = marksList.size() > 0 ? (double) total / marksList.size() : 0;
        System.out.printf("Average Marks: %.2f\n", avg);
        System.out.println("----------------------------------");
    }
}