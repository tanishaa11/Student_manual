import java.util.*;

public class Main {
    private static List<Course> availableCourses = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        // Predefine some courses
        availableCourses.add(new Course(1, "Mathematics"));
        availableCourses.add(new Course(2, "Physics"));
        availableCourses.add(new Course(3, "Chemistry"));
        availableCourses.add(new Course(4, "Computer Science"));

        System.out.println("=== Student Registration System ===");

        // Registration
        System.out.print("Enter Student ID: ");
        int sid = Integer.parseInt(scanner.nextLine());
        System.out.print("Enter Student Name: ");
        String name = scanner.nextLine();
        Student student = new Student(sid, name);

        // Course Enrollment
        System.out.println("\nAvailable Courses:");
        for (Course c : availableCourses) {
            System.out.println(c);
        }
        System.out.print("How many courses do you want to enroll in? ");
        int n = Integer.parseInt(scanner.nextLine());
        for (int i = 0; i < n; i++) {
            System.out.print("Enter Course ID to enroll: ");
            int cid = Integer.parseInt(scanner.nextLine());
            Course selected = getCourseById(cid);
            if (selected != null) {
                student.enrollCourse(selected);
            } else {
                System.out.println("Invalid Course ID. Try again.");
                i--;
            }
        }

        // Enter Marks
        List<Marks> marksList = new ArrayList<>();
        System.out.println("\nEnter marks for enrolled courses:");
        for (Course c : student.getEnrolledCourses()) {
            System.out.print("Marks for " + c.getCourseName() + ": ");
            int marks = Integer.parseInt(scanner.nextLine());
            marksList.add(new Marks(student, c, marks));
        }

        // Generate Certificate
        Certificate cert = new Certificate(student, marksList);
        cert.printCertificate();

        System.out.println("\nThank you for using the system!");
    }

    private static Course getCourseById(int id) {
        for (Course c : availableCourses) {
            if (c.getCourseId() == id) return c;
        }
        return null;
    }
}